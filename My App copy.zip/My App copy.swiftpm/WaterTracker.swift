import SwiftUI
import UserNotifications

@main
struct WaterTrackerApp: App {
    init() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
        scheduleHourlyNotifications()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

func scheduleHourlyNotifications() {
    let center = UNUserNotificationCenter.current()
    center.removeAllPendingNotificationRequests()
    
    let content = UNMutableNotificationContent()
    content.title = "💧 Time to hydrate!"
    content.body = "Don't forget to drink some water."
    content.sound = .default
    
    var dateComponents = DateComponents()
    dateComponents.minute = 0
    
    let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
    let request = UNNotificationRequest(identifier: "hourly_water_reminder", content: content, trigger: trigger)
    center.add(request)
}
