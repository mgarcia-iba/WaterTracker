import SwiftUI
import AudioToolbox

// MARK: - Models

struct DrinkEntry: Identifiable, Codable {
    let id: UUID
    let label: String
    let oz: Double
    let time: Date
    
    init(label: String, oz: Double) {
        self.id = UUID()
        self.label = label
        self.oz = oz
        self.time = Date()
    }
}

struct Container: Identifiable, Codable {
    let id: UUID
    var name: String
    var oz: Double
    
    init(name: String, oz: Double) {
        self.id = UUID()
        self.name = name
        self.oz = oz
    }
}

// MARK: - ViewModel

class WaterViewModel: ObservableObject {
    @Published var goalOz: Double {
        didSet { save() }
    }
    @Published var log: [DrinkEntry] {
        didSet { save() }
    }
    @Published var containers: [Container] {
        didSet { save() }
    }
    @Published var showConfetti: Bool = false
    @Published var timeUntilNextReminder: String = ""
    @Published var reminderPulse: Bool = false
    
    private let storageKey = "water_tracker_data"
    private var goalReachedToday = false
    private var tickTimer: Timer?
    private var midnightTimer: Timer?
    private var lastFiredMinute: Int = -1
    
    var drankOz: Double {
        log.filter { Calendar.current.isDateInToday($0.time) }
            .reduce(0) { $0 + $1.oz }
    }
    
    var todayLog: [DrinkEntry] {
        log.filter { Calendar.current.isDateInToday($0.time) }
            .sorted { $0.time > $1.time }
    }
    
    var progress: Double {
        min(1.0, drankOz / max(1, goalOz))
    }
    
    var remainingOz: Double {
        max(0, goalOz - drankOz)
    }
    
    init() {
        if let data = UserDefaults.standard.data(forKey: "water_tracker_data"),
           let decoded = try? JSONDecoder().decode(StorageModel.self, from: data) {
            self.goalOz = decoded.goalOz
            self.log = decoded.log
            self.containers = decoded.containers
        } else {
            self.goalOz = 64
            self.log = []
            self.containers = [
                Container(name: "Small glass", oz: 6),
                Container(name: "Water bottle", oz: 16),
                Container(name: "Medium bottle", oz: 24),
                Container(name: "Large bottle", oz: 35),
            ]
        }
        checkForNewDay()
        startTickTimer()
        scheduleMidnightReset()
    }
    
    deinit {
        tickTimer?.invalidate()
        midnightTimer?.invalidate()
    }
    
    // MARK: - Auto Reset
    
    func checkForNewDay() {
        let lastDate = UserDefaults.standard.string(forKey: "last_open_date") ?? ""
        let today = todayString()
        if lastDate != today {
            resetToday()
            UserDefaults.standard.set(today, forKey: "last_open_date")
        }
    }
    
    private func todayString() -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: Date())
    }
    
    private func scheduleMidnightReset() {
        midnightTimer?.invalidate()
        let cal = Calendar.current
        guard let midnight = cal.nextDate(after: Date(),
                                          matching: DateComponents(hour: 0, minute: 0, second: 0),
                                          matchingPolicy: .nextTime) else { return }
        let interval = midnight.timeIntervalSinceNow
        midnightTimer = Timer.scheduledTimer(withTimeInterval: interval, repeats: false) { [weak self] _ in
            self?.resetToday()
            UserDefaults.standard.set(self?.todayString(), forKey: "last_open_date")
            self?.scheduleMidnightReset()
        }
    }
    
    // MARK: - Hourly Reminder Timer
    
    private func startTickTimer() {
        updateReminderCountdown()
        tickTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            self?.updateReminderCountdown()
        }
    }
    
    private func playReminderSound() {
        AudioServicesPlaySystemSound(1304) // glassy water-like ping
    }
    
    private func updateReminderCountdown() {
        let now = Date()
        let cal = Calendar.current
        let components = cal.dateComponents([.minute, .second], from: now)
        let minutesPast = components.minute ?? 0
        let secondsPast = components.second ?? 0
        let totalSecondsPast = minutesPast * 60 + secondsPast
        let secondsLeft = 3600 - totalSecondsPast
        let minsLeft = secondsLeft / 60
        let secsLeft = secondsLeft % 60
        let currentMinute = cal.component(.minute, from: now)
        
        DispatchQueue.main.async {
            self.timeUntilNextReminder = String(format: "%02d:%02d", minsLeft, secsLeft)
            
            if secondsLeft == 3600 && self.lastFiredMinute != currentMinute {
                self.lastFiredMinute = currentMinute
                self.playReminderSound()
                withAnimation(.easeInOut(duration: 0.5).repeatCount(3, autoreverses: true)) {
                    self.reminderPulse = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    self.reminderPulse = false
                }
            } else if secondsLeft <= 10 {
                withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true)) {
                    self.reminderPulse = true
                }
            } else {
                self.reminderPulse = false
            }
        }
    }
    
    // MARK: - Drink Logging
    
    func logDrink(label: String, oz: Double) {
        let entry = DrinkEntry(label: label, oz: oz)
        log.insert(entry, at: 0)
        if drankOz >= goalOz && !goalReachedToday {
            goalReachedToday = true
            withAnimation { showConfetti = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                withAnimation { self.showConfetti = false }
            }
        }
    }
    
    func removeEntry(_ entry: DrinkEntry) {
        log.removeAll { $0.id == entry.id }
        if drankOz < goalOz { goalReachedToday = false }
    }
    
    func addContainer(name: String, oz: Double) {
        containers.append(Container(name: name, oz: oz))
    }
    
    func removeContainer(at offsets: IndexSet) {
        containers.remove(atOffsets: offsets)
    }
    
    func resetToday() {
        log.removeAll { Calendar.current.isDateInToday($0.time) }
        goalReachedToday = false
    }
    
    private func save() {
        let model = StorageModel(goalOz: goalOz, log: log, containers: containers)
        if let data = try? JSONEncoder().encode(model) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }
    
    private struct StorageModel: Codable {
        let goalOz: Double
        let log: [DrinkEntry]
        let containers: [Container]
    }
}

// MARK: - ContentView

struct ContentView: View {
    @StateObject private var vm = WaterViewModel()
    @Environment(\.scenePhase) private var scenePhase
    @State private var showAddContainer = false
    @State private var showGoalSheet = false
    @State private var customOzText = ""
    @State private var newContainerName = ""
    @State private var newContainerOz = ""
    
    var body: some View {
        NavigationStack {
            ZStack {
                ScrollView {
                    VStack(spacing: 20) {
                        reminderBanner
                        waveCard
                        statsRow
                        containerButtons
                        customLogRow
                        todayLogSection
                    }
                    .padding()
                }
                
                if vm.showConfetti {
                    ConfettiView()
                        .ignoresSafeArea()
                        .allowsHitTesting(false)
                }
            }
            .navigationTitle("Hydration Tracker")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("Set daily goal") { showGoalSheet = true }
                        Button("Add container") { showAddContainer = true }
                        Button(role: .destructive, action: vm.resetToday) {
                            Label("Reset today", systemImage: "arrow.counterclockwise")
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
            .sheet(isPresented: $showGoalSheet) { goalSheet }
            .sheet(isPresented: $showAddContainer) { addContainerSheet }
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .active {
                    vm.checkForNewDay()
                }
            }
        }
    }
    
    // MARK: - Reminder Banner
    
    var reminderBanner: some View {
        HStack(spacing: 12) {
            Image(systemName: "drop.fill")
                .foregroundStyle(.cyan)
                .font(.title3)
                .scaleEffect(vm.reminderPulse ? 1.2 : 1.0)
            
            VStack(alignment: .leading, spacing: 2) {
                Text("Stay hydrated! 🥤")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundStyle(.primary)
                Text("Next reminder in \(vm.timeUntilNextReminder)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
            }
            
            Spacer()
            
            VStack(alignment: .trailing, spacing: 2) {
                Text("Resets at midnight")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                Text(nextMidnightLabel())
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundStyle(.cyan)
                    .monospacedDigit()
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(Color.cyan.opacity(0.08))
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .strokeBorder(Color.cyan.opacity(0.25), lineWidth: 0.5)
                )
        )
    }
    
    func nextMidnightLabel() -> String {
        let cal = Calendar.current
        guard let midnight = cal.nextDate(after: Date(),
                                          matching: DateComponents(hour: 0, minute: 0, second: 0),
                                          matchingPolicy: .nextTime) else { return "" }
        let diff = Int(midnight.timeIntervalSinceNow)
        let h = diff / 3600
        let m = (diff % 3600) / 60
        return String(format: "%dh %02dm", h, m)
    }
    
    // MARK: - Wave Card
    
    var waveCard: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(Color(.systemGray6))
            
            GeometryReader { geo in
                let fillHeight = geo.size.height * vm.progress
                VStack {
                    Spacer()
                    Rectangle()
                        .fill(
                            LinearGradient(
                                colors: [Color.blue.opacity(0.5), Color.cyan.opacity(0.7)],
                                startPoint: .bottom,
                                endPoint: .top
                            )
                        )
                        .frame(height: fillHeight)
                        .animation(.spring(response: 0.6, dampingFraction: 0.7), value: vm.progress)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 20))
            
            VStack(spacing: 4) {
                Text("\(Int(vm.progress * 100))%")
                    .font(.system(size: 48, weight: .bold, design: .rounded))
                    .foregroundStyle(.primary)
                Text("\(formatted(vm.drankOz)) of \(formatted(vm.goalOz)) oz")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .frame(height: 180)
    }
    
    // MARK: - Stats Row
    
    var statsRow: some View {
        HStack(spacing: 12) {
            statCard(title: "Drank", value: "\(formatted(vm.drankOz)) oz", color: .blue)
            statCard(title: "Remaining", value: "\(formatted(vm.remainingOz)) oz", color: .cyan)
            statCard(title: "Goal", value: "\(formatted(vm.goalOz)) oz", color: .teal)
        }
    }
    
    func statCard(title: String, value: String, color: Color) -> some View {
        VStack(spacing: 4) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.system(.subheadline, design: .rounded, weight: .semibold))
                .foregroundStyle(color)
        }
        .frame(maxWidth: .infinity)
        .padding(12)
        .background(Color(.systemGray6), in: RoundedRectangle(cornerRadius: 12))
    }
    
    // MARK: - Container Buttons
    
    var containerButtons: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Quick add")
                .font(.headline)
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(vm.containers) { container in
                    Button {
                        vm.logDrink(label: container.name, oz: container.oz)
                    } label: {
                        VStack(spacing: 6) {
                            Image(systemName: iconName(for: container.oz))
                                .font(.title2)
                                .foregroundStyle(.blue)
                            Text(container.name)
                                .font(.subheadline)
                                .fontWeight(.medium)
                                .foregroundStyle(.primary)
                            Text("\(formatted(container.oz)) oz")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color(.systemGray6), in: RoundedRectangle(cornerRadius: 14))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
    
    // MARK: - Custom Log Row
    
    var customLogRow: some View {
        HStack(spacing: 10) {
            TextField("Custom oz...", text: $customOzText)
                .keyboardType(.decimalPad)
                .padding(10)
                .background(Color(.systemGray6), in: RoundedRectangle(cornerRadius: 10))
            
            Button("Log") {
                if let oz = Double(customOzText), oz > 0 {
                    vm.logDrink(label: "Custom (\(formatted(oz)) oz)", oz: oz)
                    customOzText = ""
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(Double(customOzText) == nil)
        }
    }
    
    // MARK: - Today's Log
    
    var todayLogSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Today's log")
                .font(.headline)
            
            if vm.todayLog.isEmpty {
                Text("No drinks logged yet")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.vertical, 12)
            } else {
                ForEach(vm.todayLog) { entry in
                    HStack {
                        Image(systemName: "drop.fill")
                            .foregroundStyle(.blue)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(entry.label)
                                .font(.subheadline)
                            Text(entry.time, style: .time)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text("\(formatted(entry.oz)) oz")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.blue)
                        Button {
                            vm.removeEntry(entry)
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundStyle(.secondary)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(12)
                    .background(Color(.systemGray6), in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }
    }
    
    // MARK: - Goal Sheet
    
    var goalSheet: some View {
        NavigationStack {
            Form {
                Section("Daily water goal") {
                    HStack {
                        TextField("64", value: $vm.goalOz, format: .number)
                            .keyboardType(.decimalPad)
                        Text("oz")
                            .foregroundStyle(.secondary)
                    }
                }
                Section {
                    ForEach([64.0, 80.0, 100.0, 128.0], id: \.self) { preset in
                        Button("\(Int(preset)) oz") {
                            vm.goalOz = preset
                            showGoalSheet = false
                        }
                    }
                } header: {
                    Text("Common goals")
                }
            }
            .navigationTitle("Set goal")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { showGoalSheet = false }
                }
            }
        }
    }
    
    // MARK: - Add Container Sheet
    
    var addContainerSheet: some View {
        NavigationStack {
            Form {
                Section("Container details") {
                    TextField("Name (e.g. Big jug)", text: $newContainerName)
                    HStack {
                        TextField("Size", text: $newContainerOz)
                            .keyboardType(.decimalPad)
                        Text("oz")
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Add container")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") {
                        newContainerName = ""
                        newContainerOz = ""
                        showAddContainer = false
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Add") {
                        if let oz = Double(newContainerOz), oz > 0, !newContainerName.isEmpty {
                            vm.addContainer(name: newContainerName, oz: oz)
                            newContainerName = ""
                            newContainerOz = ""
                            showAddContainer = false
                        }
                    }
                    .disabled(newContainerName.isEmpty || Double(newContainerOz) == nil)
                }
            }
        }
    }
    
    // MARK: - Helpers
    
    func formatted(_ value: Double) -> String {
        value.truncatingRemainder(dividingBy: 1) == 0
        ? String(Int(value))
        : String(format: "%.1f", value)
    }
    
    func iconName(for oz: Double) -> String {
        switch oz {
        case ..<10: return "cup.and.saucer.fill"
        case 10..<20: return "mug.fill"
        case 20..<30: return "waterbottle.fill"
        default: return "drop.circle.fill"
        }
    }
}

// MARK: - Confetti View

struct ConfettiView: View {
    @State private var particles: [ConfettiParticle] = []
    
    var body: some View {
        ZStack {
            ForEach(particles) { p in
                Circle()
                    .fill(p.color)
                    .frame(width: p.size, height: p.size)
                    .position(x: p.x, y: p.y)
                    .opacity(p.opacity)
            }
        }
        .onAppear { spawnParticles() }
    }
    
    func spawnParticles() {
        let colors: [Color] = [.blue, .cyan, .mint, .yellow, .pink, .orange]
        let screenW = UIScreen.main.bounds.width
        particles = (0..<60).map { _ in
            ConfettiParticle(
                x: CGFloat.random(in: 0...screenW),
                y: CGFloat.random(in: -50...200),
                size: CGFloat.random(in: 6...14),
                color: colors.randomElement()!,
                opacity: 1.0
            )
        }
        withAnimation(.easeOut(duration: 2.2)) {
            particles = particles.map { p in
                var q = p
                q.y = UIScreen.main.bounds.height + 50
                q.opacity = 0
                return q
            }
        }
    }
}

struct ConfettiParticle: Identifiable {
    let id = UUID()
    var x: CGFloat
    var y: CGFloat
    var size: CGFloat
    var color: Color
    var opacity: Double
}

#Preview {
    ContentView()
}
